Download:
setup.exe /download downloadconfig.xml

Install:
setup.exe /configure installconfig.xml